package ugb.sat.madsi.domain;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import ugb.sat.madsi.domain.Owner;

@RepositoryRestResource
public interface OwnerRepository extends CrudRepository<Owner, Long> {
}
