package esp.dgi.sb_coffee_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
